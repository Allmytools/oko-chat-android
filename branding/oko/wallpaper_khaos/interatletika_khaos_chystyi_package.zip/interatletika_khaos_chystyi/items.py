import math
from lib import *


def dims3(L, W, H, dd_px=16):
    dd = dd_px / ctx.s
    return (dim((0, W + dd, 0), (L, W + dd, 0), (0, W, 0), (L, W, 0), f"{round(L * 1000)}") +
            dim((L + dd, 0, 0), (L + dd, W, 0), (L, 0, 0), (L, W, 0), f"{round(W * 1000)}") +
            dim((-dd, W, 0), (-dd, W, H), (0, W, 0), (0, W, H), f"{round(H * 1000)}"))


def hiproof(x0, y0, x1, y1, ze, apex_z, ov=0.12):
    E = [(x0 - ov, y0 - ov, ze), (x1 + ov, y0 - ov, ze), (x1 + ov, y1 + ov, ze), (x0 - ov, y1 + ov, ze)]
    ap = ((x0 + x1) / 2, (y0 + y1) / 2, apex_z)
    s = [poly([E[3], E[0], ap]), poly([E[0], E[1], ap]), poly([E[1], E[2], ap]), poly([E[2], E[3], ap])]
    for (a, b) in [(E[1], E[2]), (E[2], E[3])]:
        for t in (0.33, 0.66):
            s.append(pl([lerp(a, ap, t), lerp(b, ap, t)], 0.5))
        for t in (0.25, 0.5, 0.75):
            s.append(pl([lerp(a, b, t), ap], 0.45, MID))
    s.append(cyl(ap[0], ap[1], apex_z - 0.02, 0.1, 0.03))
    return "".join(s)


def slide(axis, a0, a1, b0, b1, prof, hw=0.25):
    """prof: list of (t in 0..1 along a, z)"""
    def M(a, b, z):
        return (a, b, z) if axis == "x" else (b, a, z)
    s = []
    st = [(a0 + (a1 - a0) * t, z) for t, z in prof]
    for i in range(len(st) - 1):
        (aa, za), (ab, zb) = st[i], st[i + 1]
        s.append(poly([M(aa, b0, za), M(ab, b0, zb), M(ab, b0, zb + hw), M(aa, b0, za + hw)]))
        s.append(poly([M(aa, b0, za), M(aa, b1, za), M(ab, b1, zb), M(ab, b0, zb)]))
        s.append(poly([M(aa, b1, za - 0.03), M(ab, b1, zb - 0.03), M(ab, b1, zb + hw), M(aa, b1, za + hw)]))
    s.append(tube([M(a, b0, z + hw) for a, z in st], 0.035))
    s.append(tube([M(a, b1, z + hw) for a, z in st], 0.035))
    ae, ze = st[-1]
    s.append(poly([M(ae, b0, ze), M(ae, b1, ze), M(ae, b1, ze - 0.06), M(ae, b0, ze - 0.06)]))
    return "".join(s)


# 1 ------------------------------------------------------------------
def tl101():
    L, W, H = 3.051, 2.858, 2.495
    x0, y0, a, zd = 0.95, 0.95, 1.0, 0.9
    s = []
    # climbing ramp on -x
    ramp = [(0.0, y0 + 0.2, 0.0), (x0, y0 + 0.2, zd), (x0, y0 + 0.8, zd), (0.0, y0 + 0.8, 0.0)]
    s.append(poly(ramp))
    for k in range(6):
        t = 0.15 + k * 0.14
        p = lerp(ramp[0], ramp[1], t); q = lerp(ramp[3], ramp[2], t)
        m = lerp(p, q, 0.3 if k % 2 else 0.7)
        s.append(poly([(m[0], m[1] - 0.05, m[2]), (m[0] + 0.04, m[1], m[2] + 0.04), (m[0], m[1] + 0.05, m[2]), (m[0] - 0.04, m[1], m[2] - 0.04)], 0.8))
    for (px, py) in [(x0, y0), (x0 + a, y0), (x0, y0 + a), (x0 + a, y0 + a)]:
        s.append(post(px, py, zd))
    s.append(box(x0 - 0.04, y0 - 0.04, zd, a + 0.08, a + 0.08, 0.05))
    s.append(post(x0, y0, 1.0, z=zd + 0.05))
    s.append(box(x0 + 0.04, y0 - 0.02, zd + 0.1, a - 0.08, 0.03, 0.75))
    s.append(poly([(x0 + 0.5 + 0.18 * math.cos(t), y0 + 0.011, zd + 0.48 + 0.18 * math.sin(t)) for t in [k * math.pi / 20 for k in range(40)]]))
    s.append(box(x0 - 0.02, y0 + 0.04, zd + 0.1, 0.03, a - 0.08, 0.75))
    for k in range(3):
        yy = y0 + 0.25 + k * 0.22
        s.append(poly([(x0 + 0.011, yy, zd + 0.28), (x0 + 0.011, yy + 0.08, zd + 0.28), (x0 + 0.011, yy + 0.08, zd + 0.68), (x0 + 0.011, yy, zd + 0.68)], 0.8))
    s.append(post(x0 + a, y0, 1.0, z=zd + 0.05)); s.append(post(x0, y0 + a, 1.0, z=zd + 0.05))
    # slide +x
    s.append(tube([(2.75, 1.25, 0.25), (2.75, 1.25, 0.0)], 0.04)); s.append(tube([(2.75, 1.65, 0.25), (2.75, 1.65, 0.0)], 0.04))
    s.append(slide("x", x0 + a + 0.04, L, 1.2, 1.7, [(0, zd + 0.05), (0.15, zd), (0.4, 0.62), (0.75, 0.3), (1.0, 0.25)]))
    # stairs +y
    sx0, sx1 = 1.2, 1.7
    for k in range(4):
        t = (k + 1) / 5
        yy = y0 + a + 0.04 + (W - y0 - a - 0.04) * t; zz = zd - zd * t
        s.append(box(sx0, yy - 0.06, zz - 0.03, sx1 - sx0, 0.18, 0.03))
    for xx in (sx0 - 0.02, sx1 + 0.02):
        s.append(poly([(xx, y0 + a + 0.04, zd + 0.05), (xx, W, 0.0), (xx, W, 0.12), (xx, y0 + a + 0.04, zd + 0.2)], 0.9))
        s.append(tube([(xx, y0 + a + 0.02, zd + 0.75), (xx, W - 0.1, 0.65), (xx, W - 0.05, 0.1)], 0.035))
    # front rails
    s.append(tube([(x0 + a + 0.02, y0 + 0.05, zd + 0.75), (x0 + a + 0.02, y0 + 0.25, zd + 0.75)], 0.035))
    s.append(tube([(x0 + a + 0.02, y0 + 0.75, zd + 0.75), (x0 + a + 0.02, y0 + 0.95, zd + 0.75)], 0.035))
    s.append(tube([(x0 + 0.05, y0 + a + 0.02, zd + 0.75), (x0 + 0.25, y0 + a + 0.02, zd + 0.75)], 0.035))
    s.append(tube([(x0 + 0.75, y0 + a + 0.02, zd + 0.75), (x0 + 0.95, y0 + a + 0.02, zd + 0.75)], 0.035))
    s.append(post(x0 + a, y0 + a, 1.0, z=zd + 0.05))
    s.append(hiproof(x0, y0, x0 + a, y0 + a, zd + 1.05, H))
    s.append(centerline_v(x0 + a / 2, y0 + a / 2, 0, H + 0.15))
    return "".join(s), (L, W, H)


# 2 ------------------------------------------------------------------
def swing_frame(L, W, H, wood=False):
    s = []
    leg = 0.1 if wood else 0.06
    for xx, dx in ((0.12, 0.0), (L - 0.12, 0.0)):
        if wood:
            s.append(poly([(xx - 0.05, W / 2, H), (xx + 0.05, W / 2, H), (xx + 0.05, 0.0, 0.0), (xx - 0.05, 0.0, 0.0)]))
        else:
            s.append(tube([(xx, W / 2, H - 0.05), (xx, 0.0, 0.0)], leg))
    return "".join(s)


def swing_front(L, W, H, wood=False):
    s = []
    for xx in (0.12, L - 0.12):
        if wood:
            s.append(poly([(xx - 0.05, W / 2, H), (xx + 0.05, W / 2, H), (xx + 0.05, W, 0.0), (xx - 0.05, W, 0.0)]))
            s.append(box(xx - 0.05, W / 2 - 0.2, 0.9, 0.1, 0.4, 0.06))
        else:
            s.append(tube([(xx, W / 2, H - 0.05), (xx, W, 0.0)], 0.06))
            s.append(tube([(xx, W * 0.2, 0.8), (xx, W * 0.8, 0.8)], 0.04))
        s.append(box(xx - 0.08, W - 0.08, 0, 0.16, 0.16, 0.03))
        s.append(box(xx - 0.08, -0.08, 0, 0.16, 0.16, 0.03))
    return "".join(s)


def te406():
    L, W, H = 2.035, 0.985, 1.992
    s = [swing_frame(L, W, H)]
    cx = L / 2
    for xx in (cx - 0.22, cx + 0.22):
        s.append(pl([(xx, W / 2, H - 0.05), (xx, W / 2, 0.5)], 1.3, INK, "3 1.4"))
    s.append(box(cx - 0.28, W / 2 - 0.09, 0.45, 0.56, 0.18, 0.05))
    s.append(xcyl(0.0, L, W / 2, H - 0.05, 0.05))
    s.append(swing_front(L, W, H))
    return "".join(s), (L, W, H)


def te412():
    L, W, H = 2.611, 1.478, 2.225
    s = [swing_frame(L, W, H, True)]
    cx, cy, nz, r = L / 2, W / 2, 0.6, 0.5
    ang = [3 * math.pi / 4, 5 * math.pi / 4, math.pi / 4, -math.pi / 4]
    hx = [cx - 0.3, cx - 0.3, cx + 0.3, cx + 0.3]
    ring = lambda a: (cx + r * math.cos(a), cy + r * math.sin(a), nz)
    for a_, h in zip(ang, hx):
        if math.cos(a_) + math.sin(a_) <= 0:
            s.append(pl([(h, cy, H - 0.12), ring(a_)], 1.2, INK, "3 1.4"))
    web = []
    for k in range(-3, 4):
        o = k * r / 4; hh = math.sqrt(r * r - o * o)
        web.append(dpath([(cx + o, cy - hh, nz), (cx + o, cy + hh, nz)])); web.append(dpath([(cx - hh, cy + o, nz), (cx + hh, cy + o, nz)]))
    s.append(f'<path fill="none" stroke="{INK}" stroke-width="0.7" d="{" ".join(web)}"/>')
    s.append(tube(circ(cx, cy, nz, r, 64), 0.06))
    for a_, h in zip(ang, hx):
        if math.cos(a_) + math.sin(a_) > 0:
            s.append(pl([(h, cy, H - 0.12), ring(a_)], 1.2, INK, "3 1.4"))
    s.append(box(0.0, cy - 0.06, H - 0.12, L, 0.12, 0.12))
    s.append(swing_front(L, W, H - 0.12, True))
    return "".join(s), (L, W, H)


# 4 ------------------------------------------------------------------
def te208():
    L, W, H = 1.2, 0.315, 1.085
    cx, cy = L / 2, W / 2
    s = [box(cx - 0.2, cy - 0.2, 0, 0.4, 0.4, 0.02)]
    hel = [(cx + 0.09 * math.cos(t), cy + 0.09 * math.sin(t), 0.03 + 0.38 * t / (12 * math.pi)) for t in [k * 12 * math.pi / 200 for k in range(201)]]
    s.append(pl(hel, 1.8))
    prof = [(-0.6, 0.6), (-0.45, 0.66), (-0.3, 0.62), (0.15, 0.62), (0.28, 0.8), (0.34, 1.0), (0.42, 1.085), (0.58, 1.02), (0.6, 0.94), (0.46, 0.92), (0.4, 0.8),
            (0.38, 0.5), (0.22, 0.42), (-0.3, 0.42), (-0.45, 0.5), (-0.56, 0.52)]
    pan = lambda yp: poly([(cx + u, yp, v) for u, v in prof])
    s.append(tube([(cx + 0.3, -0.05, 0.88), (cx + 0.3, 0.05, 0.88)], 0.03))
    s.append(pan(cy - 0.09)); s.append(pan(cy - 0.06))
    s.append(box(cx - 0.3, cy - 0.09, 0.62, 0.42, 0.18, 0.04))
    s.append(tube([(cx + 0.05, -0.02, 0.5), (cx + 0.05, W + 0.02, 0.5)], 0.03))
    s.append(pan(cy + 0.06)); s.append(pan(cy + 0.09))
    yp = cy + 0.091
    s.append(poly([(cx + 0.38, yp, 1.06), (cx + 0.4, yp, 1.15), (cx + 0.45, yp, 1.07)], 0.9))
    s.append(poly([(cx + 0.49 + 0.022 * math.cos(t), yp, 1.0 + 0.022 * math.sin(t)) for t in [k * math.pi / 8 for k in range(16)]], 0.9))
    for k in range(5):
        u = 0.18 + k * 0.045
        s.append(pl([(cx + u, yp, 0.66 + k * 0.08), (cx + u - 0.07, yp, 0.73 + k * 0.08)], 0.8))
    s.append(pl([(cx - 0.56, yp, 0.56), (cx - 0.7, yp, 0.66), (cx - 0.72, yp, 0.5)], 1.1))
    s.append(tube([(cx + 0.3, W - 0.05, 0.88), (cx + 0.3, W + 0.05, 0.88)], 0.03))
    s.append(centerline_v(cx, cy, 0, 0.5))
    return "".join(s), (L, W, H)


# 5 ------------------------------------------------------------------
def te226():
    D, H = 1.837, 0.759
    r = D / 2; cx = cy = r
    s = [cyl(cx, cy, 0, 0.1, 0.25), cyl(cx, cy, 0.1, 0.07, r)]
    tr = []
    for k in range(12):
        a_ = 2 * math.pi * k / 12
        tr.append(dpath([(cx + 0.2 * math.cos(a_), cy + 0.2 * math.sin(a_), 0.17), (cx + (r - 0.05) * math.cos(a_), cy + (r - 0.05) * math.sin(a_), 0.17)]))
    s.append(f'<path fill="none" stroke="{MID}" stroke-width="0.5" d="{" ".join(tr)}"/>')
    rr, rz = 0.62, H
    A = [2 * math.pi * k / 4 + math.pi / 4 for k in range(4)]
    back = [a_ for a_ in A if math.cos(a_) + math.sin(a_) <= 0.01]
    front = [a_ for a_ in A if math.cos(a_) + math.sin(a_) > 0.01]
    for a_ in back:
        s.append(tube([(cx + rr * math.cos(a_), cy + rr * math.sin(a_), 0.17), (cx + rr * math.cos(a_), cy + rr * math.sin(a_), rz)], 0.035))
        s.append(tube([(cx, cy, rz), (cx + rr * math.cos(a_), cy + rr * math.sin(a_), rz)], 0.03))
    s.append(tube(circ(cx, cy, rz, rr, 40, 3 * math.pi / 4, 7 * math.pi / 4), 0.035))
    s.append(tube([(cx, cy, 0.17), (cx, cy, rz + 0.04)], 0.1))
    s.append(cyl(cx, cy, rz + 0.04, 0.03, 0.08))
    for a_ in front:
        s.append(tube([(cx, cy, rz), (cx + rr * math.cos(a_), cy + rr * math.sin(a_), rz)], 0.03))
        s.append(tube([(cx + rr * math.cos(a_), cy + rr * math.sin(a_), 0.17), (cx + rr * math.cos(a_), cy + rr * math.sin(a_), rz)], 0.035))
    s.append(tube(circ(cx, cy, rz, rr, 40, -math.pi / 4, 3 * math.pi / 4), 0.035))
    s.append(pl([(cx - r - 0.15, cy, 0.17), (cx + r + 0.15, cy, 0.17)], 0.5, INK, "9 3 2 3"))
    s.append(pl([(cx, cy - r - 0.15, 0.17), (cx, cy + r + 0.15, 0.17)], 0.5, INK, "9 3 2 3"))
    return "".join(s), (D, D, H)


# 6 ------------------------------------------------------------------
def te302():
    L = W = 1.95; H = 0.31; t = 0.08
    s = [box(0, 0, 0, L, t, H), box(0, t, 0, t, W - 2 * t, H)]
    s.append(poly([(t, t, 0.2), (L - t, t, 0.2), (L - t, W - t, 0.2), (t, W - t, 0.2)], 0.4))
    import random
    random.seed(3)
    dots = []
    for _ in range(140):
        X, Y = P(random.uniform(t + 0.05, L - t - 0.05), random.uniform(t + 0.05, W - t - 0.05), 0.2)
        dots.append(f"M{X:.1f} {Y:.1f}h0.1")
    s.append(f'<path stroke="{MID}" stroke-width="1.3" stroke-linecap="round" d="{"".join(dots)}"/>')
    s.append(box(L - t, t, 0, t, W - 2 * t, H)); s.append(box(0, W - t, 0, L, t, H))
    for (x, y) in [(0, 0), (L - 0.45, W - 0.45)]:
        s.append(box(x, y, H, 0.45, 0.45, 0.03))
    s.append(pl([(0, W, H / 2), (L, W, H / 2)], 0.5)); s.append(pl([(L, 0, H / 2), (L, W, H / 2)], 0.5))
    return "".join(s), (L, W, H)


# 7 ------------------------------------------------------------------
def te102():
    L, W, H = 3.511, 0.563, 2.28
    zp = 1.2; xp0, xp1 = 0.75, 1.25
    s = []
    for xx in (xp0, xp1):
        s.append(post(xx, 0.04, zp)); s.append(post(xx, W - 0.04, zp))
    for k in range(5):
        t = (k + 1) / 6
        x = xp0 * (1 - t); z = zp * t
        s.append(box(x - 0.08, 0.06, z - 0.03, 0.16, W - 0.12, 0.03))
    s.append(box(xp0 - 0.04, 0.0, zp, xp1 - xp0 + 0.08, W, 0.05))
    s.append(tube([(xp0, 0.02, zp + 0.06), (xp0, 0.02, H - 0.25), (xp0 + 0.12, 0.02, H), (xp1 - 0.12, 0.02, H), (xp1, 0.02, H - 0.25), (xp1, 0.02, zp + 0.06)], 0.035))
    s.append(slide("x", xp1 + 0.04, L, 0.03, W - 0.03, [(0, zp + 0.05), (0.12, zp), (0.4, 0.75), (0.75, 0.32), (1.0, 0.28)], 0.2))
    s.append(tube([(L - 0.25, 0.1, 0.27), (L - 0.25, 0.1, 0.0)], 0.04)); s.append(tube([(L - 0.25, W - 0.1, 0.27), (L - 0.25, W - 0.1, 0.0)], 0.04))
    for yy in (0.0, W):
        s.append(poly([(0.0, yy, 0.0), (0.06, yy, 0.0), (xp0 + 0.05, yy, zp), (xp0 - 0.02, yy, zp)], 0.9))
        s.append(tube([(0.02, yy, 0.6), (xp0 - 0.02, yy, zp + 0.7), (xp0, yy, H - 0.25)], 0.035))
    s.append(tube([(xp0, W - 0.02, zp + 0.06), (xp0, W - 0.02, H - 0.25), (xp0 + 0.12, W - 0.02, H), (xp1 - 0.12, W - 0.02, H), (xp1, W - 0.02, H - 0.25), (xp1, W - 0.02, zp + 0.06)], 0.035))
    return "".join(s), (L, W, H)


# 8 ------------------------------------------------------------------
def te222():
    L, W, H = 2.5, 0.556, 0.728
    cx, cy = L / 2, W / 2
    s = [box(cx - 0.18, cy - 0.15, 0, 0.36, 0.3, 0.38)]
    tilt = 0.12
    zc = 0.42
    z = lambda x: zc + (x - cx) / (L / 2) * tilt * 1.6
    s.append(poly([(0.1, cy - 0.06, z(0.1)), (L - 0.1, cy - 0.06, z(L - 0.1)), (L - 0.1, cy + 0.06, z(L - 0.1)), (0.1, cy + 0.06, z(0.1))]))
    s.append(poly([(0.1, cy + 0.06, z(0.1)), (L - 0.1, cy + 0.06, z(L - 0.1)), (L - 0.1, cy + 0.06, z(L - 0.1) - 0.06), (0.1, cy + 0.06, z(0.1) - 0.06)]))
    for xs in (0.25, L - 0.25):
        zz = z(xs)
        s.append(box(xs - 0.16, cy - 0.17, zz, 0.32, 0.34, 0.04))
        hx = xs + (0.24 if xs < cx else -0.24)
        s.append(tube([(hx, cy - 0.12, zz), (hx, cy - 0.12, zz + 0.28), (hx, cy + 0.12, zz + 0.28), (hx, cy + 0.12, zz)], 0.03))
    s.append(ycyl(cy - 0.17, cy + 0.17, cx, 0.4, 0.05))
    for xs in (0.35, L - 0.35):
        s.append(cyl(xs, cy, 0, 0.08, 0.09))
    return "".join(s), (L, W, H)


# 9 ------------------------------------------------------------------
def mf111():
    L, W, H = 1.23, 0.283, 2.466
    s = [box(0, 0, 0, 0.08, 0.08, H), box(L - 0.08, 0, 0, 0.08, 0.08, H)]
    for k in range(11):
        zz = 0.25 + k * 0.205
        s.append(tube([(0.08, W * 0.5, zz), (L - 0.08, W * 0.5, zz)], 0.032))
    s.append(box(0.0, 0.08, 0.0, 0.08, W - 0.08, 0.06)); s.append(box(L - 0.08, 0.08, 0, 0.08, W - 0.08, 0.06))
    s.append(box(-0.02, -0.02, H, 0.12, 0.12, 0.02)); s.append(box(L - 0.1, -0.02, H, 0.12, 0.12, 0.02))
    return "".join(s), (L, W, H)


# 11 -----------------------------------------------------------------
def mf34():
    L, W, H = 3.164, 0.714, 2.526
    s = []
    xs = [0.04, 1.08, 2.12, L - 0.04]
    zs = [H, 2.2, H - 0.2]
    cy = W / 2
    for i in range(3):
        s.append(box(xs[i] - 0.04, cy - 0.04, 0, 0.08, 0.08, max(zs[i], zs[i - 1] if i else zs[0])))
    # pull-up bars
    s.append(tube([(xs[0], cy, H - 0.06), (xs[1], cy, H - 0.06)], 0.035))
    s.append(tube([(xs[1], cy, 2.1), (xs[2], cy, 2.1)], 0.035))
    # wall bars in bay 3
    for k in range(8):
        zz = 0.3 + k * 0.24
        s.append(tube([(xs[2], cy, zz), (xs[3], cy, zz)], 0.03))
    # dip bars on bay 2
    for yy in (cy - 0.28, cy + 0.28):
        s.append(tube([(xs[1] + 0.1, yy, 1.25), (xs[2] - 0.1, yy, 1.25)], 0.04))
        s.append(tube([(xs[1] + 0.25, yy, 1.25), (xs[1] + 0.25, yy, 0.0)], 0.04))
        s.append(tube([(xs[2] - 0.25, yy, 1.25), (xs[2] - 0.25, yy, 0.0)], 0.04))
    s.append(box(xs[3] - 0.04, cy - 0.04, 0, 0.08, 0.08, H - 0.2))
    s.append(tube([(xs[2], cy, H - 0.26), (xs[3], cy, H - 0.26)], 0.035))
    # bench in bay 1
    s.append(box(xs[0] + 0.15, cy - 0.15, 0.42, 0.8, 0.3, 0.05))
    s.append(tube([(xs[0] + 0.25, cy, 0.42), (xs[0] + 0.25, cy, 0)], 0.05))
    s.append(tube([(xs[0] + 0.85, cy, 0.42), (xs[0] + 0.85, cy, 0)], 0.05))
    for x in xs:
        s.append(box(x - 0.08, cy - 0.08, 0, 0.16, 0.16, 0.02))
    return "".join(s), (L, W, H)


# 12 -----------------------------------------------------------------
def ut417():
    L, W, H = 2.089, 1.8, 3.93
    s = []
    s.append(box(0.0, 0.2, 0.0, 0.9, 1.4, 0.08))
    s.append(box(0.15, W / 2 - 0.08, 0.08, 0.16, 0.16, 2.95))
    s.append(tube([(0.23, W / 2, 1.6), (0.9, W / 2, 0.08)], 0.07))
    s.append(tube([(0.23, W / 2, 2.95), (1.55, W / 2, 3.2)], 0.08))
    s.append(tube([(0.23, W / 2, 2.4), (1.5, W / 2, 3.0)], 0.06))
    bx = 1.6
    s.append(poly([(bx, 0.0, 2.875), (bx, W, 2.875), (bx, W, 3.93), (bx, 0.0, 3.93)]))
    s.append(poly([(bx + 0.03, 0.0, 2.875), (bx + 0.03, W, 2.875), (bx + 0.03, W, 3.93), (bx + 0.03, 0.0, 3.93)]))
    s.append(poly([(bx + 0.031, W / 2 - 0.295, 3.03), (bx + 0.031, W / 2 + 0.295, 3.03), (bx + 0.031, W / 2 + 0.295, 3.48), (bx + 0.031, W / 2 - 0.295, 3.48)]))
    rc = (bx + 0.03 + 0.15 + 0.225, W / 2, 3.05)
    net = []
    for k in range(12):
        a_ = 2 * math.pi * k / 12
        p0 = (rc[0] + 0.225 * math.cos(a_), rc[1] + 0.225 * math.sin(a_), rc[2])
        p1 = (rc[0] + 0.14 * math.cos(a_ + 0.3), rc[1] + 0.14 * math.sin(a_ + 0.3), rc[2] - 0.42)
        net.append(dpath([p0, p1]))
    s.append(f'<path fill="none" stroke="{INK}" stroke-width="0.6" d="{" ".join(net)}"/>')
    s.append(pl(circ(rc[0], rc[1], rc[2] - 0.42, 0.14, 30), 0.6))
    s.append(pl(circ(rc[0], rc[1], rc[2] - 0.2, 0.18, 30), 0.6))
    s.append(tube(circ(rc[0], rc[1], rc[2], 0.225, 40), 0.02))
    s.append(box(bx + 0.03, W / 2 - 0.06, 2.98, 0.15, 0.12, 0.06))
    s.append(centerline_v(rc[0], rc[1], 0, rc[2] - 0.5))
    return "".join(s), (L, W, H)


# 13 -----------------------------------------------------------------
def ut603():
    L, W, H = 5.16, 1.555, 2.08
    s = []
    fy = W
    net = []
    for k in range(1, 26):
        x = L * k / 26
        net.append(dpath([(x, fy, H), (x, 0.3, H - 0.25), (x, 0.0, 0.0)]))
    for k in range(1, 9):
        t = k / 9
        net.append(dpath([(0, fy * (1 - t) + 0.3 * t, H - 0.25 * t), (L, fy * (1 - t) + 0.3 * t, H - 0.25 * t)]))
        net.append(dpath([(0, 0.3 * (1 - t), (H - 0.25) * (1 - t)), (L, 0.3 * (1 - t), (H - 0.25) * (1 - t))]))
    s.append(f'<path fill="none" stroke="{MID}" stroke-width="0.45" d="{" ".join(net)}"/>')
    s.append(tube([(0.0, fy, H), (0.0, 0.3, H - 0.25), (0.0, 0.0, 0.0), (L, 0.0, 0.0), (L, 0.3, H - 0.25), (L, fy, H)], 0.035))
    s.append(tube([(0.0, fy, 0.0), (0.0, 0.0, 0.0)], 0.035)); s.append(tube([(L, fy, 0.0), (L, 0.0, 0.0)], 0.035))
    s.append(tube([(0.0, fy, 0.0), (0.0, fy, H), (L, fy, H), (L, fy, 0.0)], 0.08))
    return "".join(s), (L, W, H)


# 14 outdoor trainers ------------------------------------------------
def pillar(x, y, h, r=0.057):
    return cyl(x, y, 0, h, r) + cyl(x, y, h, 0.02, r + 0.01)


def se201():
    L, W, H = 0.952, 0.875, 1.948
    cx, cy = 0.25, W / 2
    s = [cyl(cx, cy, 0, 0.03, 0.15)]
    s.append(pillar(cx, cy, H - 0.05))
    s.append(box(cx + 0.06, cy - 0.17, 0.45, 0.4, 0.34, 0.06))
    s.append(tube([(cx, cy, 0.48), (cx + 0.06, cy, 0.48)], 0.05))
    s.append(box(cx + 0.06, cy - 0.16, 0.55, 0.06, 0.32, 0.6))
    for sg in (-1, 1):
        yy = cy + sg * 0.3
        s.append(tube([(cx, cy, H - 0.25), (cx + 0.05, yy, H - 0.3), (L - 0.05, yy, 1.05)], 0.04))
        s.append(tube([(L - 0.05, yy, 1.05), (L - 0.05, yy + sg * 0.12, 1.05)], 0.035))
    return "".join(s), (L, W, H)


def se115():
    L, W, H = 1.071, 0.48, 1.519
    cy = W / 2
    s = [tube([(0.2, cy, 0.0), (0.45, cy, H - 0.15)], 0.11), tube([(0.75, cy, 0.0), (0.5, cy, H - 0.15)], 0.08)]
    for sg, ph in ((-1, 0.35), (1, -0.3)):
        yy = cy + sg * 0.16
        bot = (0.5 + ph, yy, 0.25)
        s.append(tube([(0.48, yy, H - 0.2), bot], 0.04))
        s.append(box(bot[0] - 0.18, yy - 0.08, 0.2, 0.36, 0.16, 0.04))
    s.append(tube([(0.48, cy - 0.24, H - 0.2), (0.48, cy + 0.24, H - 0.2)], 0.05))
    s.append(tube([(0.5, cy, H - 0.15), (0.62, cy, H), (0.62, cy - 0.24, H), (0.62, cy + 0.24, H)], 0.035))
    s.append(cyl(0.2, cy, 0, 0.02, 0.12)); s.append(cyl(0.75, cy, 0, 0.02, 0.1))
    return "".join(s), (L, W, H)


def se236():
    L, W, H = 0.843, 0.551, 1.435
    cy = W / 2
    s = [cyl(0.15, cy, 0, 0.02, 0.13), pillar(0.15, cy, H - 0.1)]
    s.append(tube([(0.15, cy, H - 0.15), (0.35, cy, H - 0.05), (0.35, cy - 0.25, H - 0.05), (0.35, cy + 0.25, H - 0.05)], 0.035))
    for sg, zz in ((-1, 0.35), (1, 0.2)):
        yy = cy + sg * 0.15
        s.append(tube([(0.15, yy, 0.55), (0.6, yy, zz)], 0.05))
        s.append(box(0.55, yy - 0.09, zz - 0.02, 0.29, 0.18, 0.035))
    s.append(tube([(0.15, cy - 0.15, 0.55), (0.15, cy + 0.15, 0.55)], 0.04))
    return "".join(s), (L, W, H)


def kf811():
    L, W, H = 2.57, 1.0, 1.14
    s = []
    for yy in (0.18, W - 0.18):
        s.append(tube([(0.15, yy, 0.0), (0.15, yy, H), (L - 0.15, yy, H), (L - 0.15, yy, 0.0)], 0.06))
        s.append(tube([(1.0, yy, 0.0), (1.0, yy, H)], 0.05))
        s.append(tube([(L - 0.6, yy, 0.0), (L - 0.6, yy, H)], 0.05))
    for x in (0.15, L - 0.15):
        s.append(tube([(x, 0.18, 0.55), (x, W - 0.18, 0.55)], 0.05))
    for x in (0.15, 1.0, L - 0.6, L - 0.15):
        for yy in (0.18, W - 0.18):
            s.append(box(x - 0.1, yy - 0.1, 0, 0.2, 0.2, 0.015))
    return "".join(s), (L, W, H)


# gym --------------------------------------------------------------------
def dumbbell():
    L, W, H = 0.33, 0.13, 0.13
    cz = H / 2; cy = W / 2
    def hexx(x):
        return [(x, cy + 0.065 * math.cos(math.pi / 6 + k * math.pi / 3), cz + 0.065 * math.sin(math.pi / 6 + k * math.pi / 3)) for k in range(7)]
    s = []
    for (x0, x1) in ((0.0, 0.07), (L - 0.07, L)):
        a = hexx(x0); b = hexx(x1)
        s.append(hullpoly(a + b)); s.append(poly(b))
        s.append(poly([(x1, cy + 0.04 * math.cos(math.pi / 6 + k * math.pi / 3), cz + 0.04 * math.sin(math.pi / 6 + k * math.pi / 3)) for k in range(7)], 0.5))
        if x0 == 0.0:
            s.append(xcyl(0.07, L - 0.07, cy, cz, 0.017))
            knurl = []
            for k in range(12):
                x = 0.1 + k * 0.011
                knurl.append(dpath([(x, cy - 0.017, cz - 0.003), (x + 0.005, cy + 0.017, cz + 0.003)]))
            s.append(f'<path fill="none" stroke="{INK}" stroke-width="0.4" d="{" ".join(knurl)}"/>')
    return "".join(s), (L, W, H)


def barbell():
    L, W, H = 2.2, 0.45, 0.45
    cy, cz = W / 2, H / 2
    s = [xcyl(0.0, 0.42, cy, cz, 0.025)]
    plates = [(0.06, 0.06, 0.225), (0.12, 0.05, 0.225), (0.17, 0.04, 0.17)]
    x = 0.06
    for (x0, t, r) in plates:
        s.append(xcyl(x0, x0 + t, cy, cz, r))
        s.append(pl(vcirc_x(x0 + t + 0.001, cy, cz, r * 0.4, 30), 0.5))
    s.append(xcyl(0.21, 0.24, cy, cz, 0.035))
    s.append(xcyl(0.24, L - 0.24, cy, cz, 0.014))
    s.append(xcyl(L - 0.24, L - 0.21, cy, cz, 0.035))
    s.append(xcyl(L - 0.42, L, cy, cz, 0.025))
    for (x0, t, r) in [(L - 0.21, 0.04, 0.17), (L - 0.17, 0.05, 0.225), (L - 0.12, 0.06, 0.225)]:
        s.append(xcyl(x0, x0 + t, cy, cz, r))
        s.append(pl(vcirc_x(x0 + t + 0.001, cy, cz, r * 0.4, 30), 0.5))
        s.append(pl(vcirc_x(x0 + t + 0.001, cy, cz, r * 0.85, 40), 0.4, MID))
    s.append(pl([(-0.08, cy, cz), (L + 0.08, cy, cz)], 0.5, INK, "9 3 2 3"))
    return "".join(s), (L, W, H)


def kettlebell():
    L = W = 0.21; H = 0.29
    cx = cy = 0.105
    s = [cyl(cx, cy, 0, 0.01, 0.07)]
    # body as sphere outline
    X, Y = P(cx, cy, 0.105)
    r = 0.105 * ctx.s
    s.append(f'<circle cx="{X:.1f}" cy="{Y:.1f}" r="{r:.1f}" fill="{BG}" stroke="{INK}" stroke-width="1.1"/>')
    s.append(pl(circ(cx, cy, 0.105, 0.105, 40, -math.pi * 0.75, math.pi * 0.25), 0.5, MID))
    s.append(tube([(cx, cy - 0.07, 0.17), (cx, cy - 0.08, 0.25), (cx, cy - 0.04, 0.29), (cx, cy + 0.04, 0.29), (cx, cy + 0.08, 0.25), (cx, cy + 0.07, 0.17)], 0.03))
    return "".join(s), (L, W, H)


def plate():
    L, W, H = 0.06, 0.45, 0.45
    cy, cz = W / 2, H / 2
    s = [xcyl(0.0, L, cy, cz, 0.225)]
    s.append(pl(vcirc_x(L + 0.001, cy, cz, 0.19, 50), 0.5))
    s.append(pl(vcirc_x(L + 0.001, cy, cz, 0.06, 30), 0.7))
    s.append(poly(vcirc_x(L + 0.002, cy, cz, 0.026, 24), 0.8))
    for a_ in (0.6, 0.6 + 2.1, 0.6 + 4.2):
        y = cy + 0.13 * math.cos(a_); z = cz + 0.13 * math.sin(a_)
        s.append(poly([(L + 0.002, y + 0.035 * math.cos(t), z + 0.022 * math.sin(t)) for t in [k * math.pi / 10 for k in range(20)]], 0.6))
    s.append(pl([(L, cy - 0.27, cz), (L, cy + 0.27, cz)], 0.45, INK, "9 3 2 3"))
    s.append(pl([(L, cy, cz - 0.27), (L, cy, cz + 0.27)], 0.45, INK, "9 3 2 3"))
    return "".join(s), (L, W, H)


def rack():
    L, W, H = 1.4, 1.3, 2.3
    s = []
    ups = [(0.05, 0.05), (L - 0.05, 0.05), (0.05, W - 0.05), (L - 0.05, W - 0.05)]
    s.append(box(0.0, 0.0, 0.0, L, 0.08, 0.04)); s.append(box(0.0, 0.08, 0.0, 0.08, W - 0.16, 0.04))
    for (x, y) in ups[:3]:
        s.append(box(x - 0.04, y - 0.04, 0.04, 0.08, 0.08, H - 0.04))
    holes = []
    for (x, y) in ups:
        for k in range(18):
            z = 0.5 + k * 0.08
            X, Y = P(x + 0.04, y, z)
            holes.append(f"M{X - 1.2:.1f} {Y:.1f}a1.2 1.2 0 1 0 2.4 0a1.2 1.2 0 1 0 -2.4 0")
    s.append(box(0.0, W - 0.08, 0.0, L, 0.08, 0.04)); s.append(box(L - 0.08, 0.08, 0.0, 0.08, W - 0.16, 0.04))
    # barbell on hooks
    s.append(xcyl(-0.25, L + 0.25, W * 0.25, 1.4, 0.016))
    for xx in (-0.2, L + 0.05):
        s.append(xcyl(xx, xx + 0.15, W * 0.25, 1.4, 0.225))
    s.append(box(ups[3][0] - 0.04, ups[3][1] - 0.04, 0.04, 0.08, 0.08, H - 0.04))
    s.append(f'<path fill="{INK}" stroke="none" d="{"".join(holes)}"/>')
    for a, b in [((0.05, 0.05), (L - 0.05, 0.05)), ((0.05, 0.05), (0.05, W - 0.05)), ((L - 0.05, 0.05), (L - 0.05, W - 0.05)), ((0.05, W - 0.05), (L - 0.05, W - 0.05))]:
        s.append(box(min(a[0], b[0]) - 0.04, min(a[1], b[1]) - 0.04, H - 0.08, abs(b[0] - a[0]) + 0.08, abs(b[1] - a[1]) + 0.08, 0.08) if False else "")
    s.append(box(0.01, 0.01, H, L - 0.02, 0.08, 0.06)); s.append(box(0.01, 0.09, H, 0.08, W - 0.18, 0.06))
    s.append(box(L - 0.09, 0.09, H, 0.08, W - 0.18, 0.06)); s.append(box(0.01, W - 0.09, H, L - 0.02, 0.08, 0.06))
    s.append(tube([(0.2, W - 0.05, H - 0.15), (L - 0.2, W - 0.05, H - 0.15)], 0.035))
    return "".join(s), (L, W, H)


def bench():
    L, W, H = 1.25, 0.6, 0.45
    cy = W / 2
    s = [box(0.0, cy - 0.3, 0, 0.08, 0.6, 0.05), box(L - 0.08, cy - 0.3, 0, 0.08, 0.6, 0.05)]
    s.append(box(0.04, cy - 0.04, 0.05, L - 0.08, 0.08, 0.08))
    s.append(box(0.15, cy - 0.04, 0.13, 0.08, 0.08, 0.2)); s.append(box(L - 0.25, cy - 0.04, 0.13, 0.08, 0.08, 0.2))
    s.append(box(0.0, cy - 0.15, 0.33, L, 0.3, 0.1))
    s.append(pl([(0.45, cy - 0.15, 0.43), (0.45, cy + 0.15, 0.43), (0.45, cy + 0.15, 0.33)], 0.6))
    return "".join(s), (L, W, H)
