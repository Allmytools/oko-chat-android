# Техно-шпалери «Інтератлетика» — варіант «хаос без підписів»

Еталон: `etalon/interatletika_khaos_chystyi_3840x2160.png` (робочий стіл) і `etalon/interatletika_khaos_chystyi_phone_1290x2796.png` (телефон).
Вихідні SVG: `etalon/khaos_chystyi_desktop.svg`, `etalon/khaos_chystyi_phone.svg`.

Без ярликів з артикулами, без виносок і без штампу з логотипом. Залишаються контури виробів, розмірні лінії, бліді креслярські фрагменти, сітка й тонкі уривки рамки.

## Склад
| Шлях | Що це |
|---|---|
| `photos/<категорія>/<артикул>_1.jpg` | головні фото виробів (білий фон), з prof/play.interatletika.ua |
| `photos/manifest.csv` | артикул, назва, габарити Д×Ш×В, url (UTF-8 BOM, «;») |
| `lines/<артикул>.png` | готові контури виробів (RGBA: лінія `#B9AD9C`, заливка силуету `#EFEAE2`, решта прозора) |
| `trace.py` | фото → контур (OpenCV) |
| `art.py` | збирає композицію «хаос» у SVG |
| `lib.py`, `main.py`, `compose.py`, `items.py` | палітра, шрифт, креслярські фрагменти, допоміжні функції |
| `logo_blidi.png`, `logo_source_screenshot_crop.png` | логотип — у цьому варіанті не використовується (для варіанта зі штампом) |

## Залежності
- Python 3.10+, `pillow`, `numpy`, `opencv-python`, `scipy`
- `rsvg-convert` (librsvg) для SVG → PNG
- шрифт **Liberation Sans Narrow** (курсив) — для чисел на розмірних лініях

## Збірка (з кореня цієї теки)
```bash
python3 trace.py photos/*/*_1.jpg                        # (необов'язково) перегенерувати lines/*.png
NOTAG=1 NOTB=1 BASE_D=310 python3 art.py desktop 3       # -> art_desktop.svg  (seed 3)
NOTAG=1 NOTB=1 BASE_P=215 python3 art.py phone 4         # -> art_phone.svg    (seed 4)
rsvg-convert -w 3840 -h 2160 art_desktop.svg -o khaos_3840x2160.png
rsvg-convert -w 1290 -h 2796 art_phone.svg  -o khaos_phone_1290x2796.png
```
Перевірено: з цими параметрами результат збігається з еталоном піксель у піксель.

## Параметри
| Змінна / аргумент | Значення в еталоні | Що робить |
|---|---|---|
| seed (2-й аргумент `art.py`) | 3 (desktop), 4 (phone) | розстановка й кути |
| `BASE_D` / `BASE_P` | 310 / 215 | базовий розмір виробу, од. viewBox (1920×1080 / 645×1398) |
| `ROTMAX` | 35 | максимальний кут нахилу виробу, ° (мінімум 6°) |
| `NOTAG` | 1 | 1 = без ярликів з артикулами й виносок |
| `NOTB` | 1 | 1 = без штампу з логотипом |
