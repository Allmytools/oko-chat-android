import sys, math, random, base64, io, csv, os
sys.path.insert(0, ".")
from PIL import Image
from lib import BG, INK, MID, FONT
import main as M

LOGO = "./logo_blidi.png"
TOOL = "#CEC4B7"
TFILL = "#ECE6DD"
FAINT = M.FAINT

NAMES = {
    "T903_NEW": ("T903 NEW", "Ігровий комплекс «Замок-NEW»"), "TL101": ("TL101", "Ігровий комплекс «Березень»"),
    "TE412-RC": ("TE412-RC", "Гойдалка «Гніздо Лелеки»"), "TE406": ("TE406", "Гойдалка одинарна на ланцюгах"),
    "TE230": ("TE230", "Гойдалка на пружині «Птах»"), "TE226": ("TE226", "Карусель"),
    "TE302": ("TE302", "Пісочниця середня"), "TE102": ("TE102", "Гірка велика"),
    "MF3.4": ("MF3.4", "Станція воркаут"), "MF1.11": ("MF1.11", "Шведська стінка"), "MF1.5": ("MF1.5", "Бруси"),
    "UT417": ("УТ417", "Стенд баскетбольний FIBA"), "SE201": ("SE201", "Жим від грудей"),
    "SE115": ("SE115", "Повітряний ходок"), "SE236": ("SE236", "Степпер"), "SE204": ("SE204", "Маятник"),
    "KF811-S": ("KF811-S", "EXPLODE"), "KF812-S": ("KF812-S", "Розгинач стегна EXPLODE"),
    "XP107": ("XP107", "Розгинач стегна X Power"), "UP106": ("UP106", "Біцепс-машина U Power"),
    "V210": ("V210", "Тяга важеля Verti"), "ST206": ("ST206", "Жим під кутом вгору"), "ST201": ("ST201", "Машина Сміта"),
    "ST314": ("ST314", "Лава для жиму універсальна"), "XP103": ("XP103", "Кросовер X Power"),
    "ST555.20": ("ST555.20", "Гантель професійна 20 кг"), "MD2102-37.5": ("MD2102", "Гантель гексагональна 37,5 кг"),
    "PD193-1-28": ("PD193", "Гиря EXPLODE 28 кг"), "ST581-15": ("ST581-15", "Штанга W-подібна 15 кг"),
    "LCAH043-M": ("LCAH043-M", "Диск 1,25 кг"), "C3-27": ("C3-27", "Гриф олімпійський 2200 мм"),
}
DIMS = {}
for r in csv.DictReader(open("./photos/manifest.csv", encoding="utf-8-sig"), delimiter=";"):
    key = os.path.basename(r["файл_фото"]).replace("_1.jpg", "").replace("_2.jpg", "")
    DIMS.setdefault(key, (r["довжина_мм"].strip(), r["ширина_мм"].strip(), r["висота_мм"].strip()))

SIZE = {  # relative size class
    "T903_NEW": 1.55, "XP103": 1.35, "ST201": 1.3, "TE412-RC": 1.2, "TL101": 1.2, "UT417": 1.25, "MF3.4": 1.15,
    "TE102": 1.05, "ST206": 1.1, "KF812-S": 1.05, "KF811-S": 1.0, "XP107": 1.0, "UP106": 1.0, "V210": 1.0, "ST314": 0.95,
    "TE406": 1.05, "MF1.11": 1.0, "MF1.5": 0.9, "SE201": 0.95, "SE115": 0.95, "SE236": 0.9, "SE204": 0.9,
    "TE226": 0.85, "TE230": 0.8, "TE302": 0.85, "ST555.20": 0.7, "MD2102-37.5": 0.7, "PD193-1-28": 0.62,
    "ST581-15": 0.85, "LCAH043-M": 0.6,
}


def img_b64(key, maxpx):
    im = Image.open(f"./lines/{key}.png")
    im.thumbnail((maxpx, maxpx), Image.LANCZOS)
    buf = io.BytesIO(); im.save(buf, "PNG", optimize=True)
    return im.size, base64.b64encode(buf.getvalue()).decode()


def t(x, y, s, size=11, ang=0, col=INK, anchor="middle", weight="normal"):
    return (f'<text x="{x:.1f}" y="{y:.1f}" font-size="{size}" fill="{col}" text-anchor="{anchor}" font-weight="{weight}" {FONT} '
            f'transform="rotate({ang:.1f} {x:.1f} {y:.1f})">{s}</text>')


def ln(x1, y1, x2, y2, w=0.8, col=INK, dash=None):
    d = f' stroke-dasharray="{dash}"' if dash else ""
    return f'<path stroke="{col}" stroke-width="{w}" fill="none"{d} d="M{x1:.1f} {y1:.1f} L{x2:.1f} {y2:.1f}"/>'


def arr(x, y, ux, uy, col=INK, s=6):
    px, py = -uy, ux
    return f'<path fill="{col}" d="M{x:.1f} {y:.1f} L{x - ux * s + px * s * .3:.1f} {y - uy * s + py * s * .3:.1f} L{x - ux * s - px * s * .3:.1f} {y - uy * s - py * s * .3:.1f}Z"/>'


# ---------------------------------------------------------------- tools
def caliper(col=TOOL):
    s = []
    P = lambda pts: f'<path fill="{TFILL}" stroke="{col}" stroke-width="1.2" stroke-linejoin="round" d="M' + " L".join(f"{x} {y}" for x, y in pts) + 'Z"/>'
    s.append(P([(0, 0), (0, -60), (12, -60), (30, 0)]))
    s.append(P([(0, 34), (0, 200), (16, 214), (44, 120), (44, 34)]))
    s.append(f'<rect x="0" y="0" width="720" height="34" fill="{TFILL}" stroke="{col}" stroke-width="1.2"/>')
    s.append(f'<rect x="720" y="13" width="70" height="8" fill="{TFILL}" stroke="{col}" stroke-width="1"/>')
    tk = []
    for i in range(0, 191):
        x = 40 + i * 3.5
        if x > 712: break
        L = 12 if i % 10 == 0 else (8 if i % 5 == 0 else 5)
        tk.append(f"M{x:.1f} 0V{L}")
        if i % 10 == 0:
            s.append(t(x, 24, str(i // 10), 9.5, 0, col))
    s.append(f'<path stroke="{col}" stroke-width="0.6" d="{"".join(tk)}"/>')
    sx = 250
    s.append(P([(sx, 64), (sx + 20, 140), (sx + 30, 214), (sx + 46, 200), (sx + 40, 64)]))
    s.append(P([(sx, -8), (sx - 4, -54), (sx + 8, -54), (sx + 22, -8)]))
    s.append(f'<rect x="{sx}" y="-8" width="140" height="72" rx="6" fill="{TFILL}" stroke="{col}" stroke-width="1.2"/>')
    s.append(f'<rect x="{sx + 10}" y="36" width="120" height="20" fill="none" stroke="{col}" stroke-width="0.8"/>')
    vk = []
    for i in range(0, 51):
        x = sx + 14 + i * 2.25
        L = 9 if i % 5 == 0 else 5
        vk.append(f"M{x:.1f} 36V{36 + L}")
    s.append(f'<path stroke="{col}" stroke-width="0.5" d="{"".join(vk)}"/>')
    s.append(f'<circle cx="{sx + 70}" cy="78" r="12" fill="{TFILL}" stroke="{col}" stroke-width="1.1"/>')
    s.append(f'<rect x="{sx + 60}" y="-20" width="20" height="12" fill="{TFILL}" stroke="{col}" stroke-width="1"/>')
    s.append(t(560, 54, "0–200 мм   0,05", 10, 0, col))
    return "".join(s)


def tape(col=TOOL):
    s = [f'<rect x="760" y="134" width="40" height="44" fill="{TFILL}" stroke="{col}" stroke-width="1.1"/>']
    s.append(f'<rect x="180" y="148" width="600" height="26" fill="{TFILL}" stroke="{col}" stroke-width="1.1"/>')
    tk = []
    for i in range(0, 600, 4):
        L = 12 if i % 40 == 0 else (8 if i % 20 == 0 else 4)
        tk.append(f"M{180 + i} 148V{148 + L}")
        if i % 40 == 0 and i:
            s.append(t(180 + i, 171, str(i // 4), 9, 0, col))
    s.append(f'<path stroke="{col}" stroke-width="0.55" d="{"".join(tk)}"/>')
    s.append(f'<rect x="0" y="0" width="190" height="190" rx="34" fill="{TFILL}" stroke="{col}" stroke-width="1.3"/>')
    s.append(f'<rect x="12" y="12" width="166" height="166" rx="26" fill="none" stroke="{col}" stroke-width="0.7"/>')
    s.append(f'<circle cx="95" cy="95" r="58" fill="none" stroke="{col}" stroke-width="1"/>')
    s.append(f'<circle cx="95" cy="95" r="12" fill="none" stroke="{col}" stroke-width="1"/>')
    s.append(f'<rect x="120" y="-8" width="40" height="16" rx="4" fill="{TFILL}" stroke="{col}" stroke-width="1"/>')
    s.append(t(95, 105, "5 м", 13, 0, col))
    return "".join(s)


def ruler(col=TOOL, L=900):
    s = [f'<rect x="0" y="0" width="{L}" height="42" fill="{TFILL}" stroke="{col}" stroke-width="1.2"/>']
    tk = []
    n = int((L - 40) / 3)
    for i in range(n + 1):
        x = 20 + i * 3
        h = 14 if i % 10 == 0 else (9 if i % 5 == 0 else 5)
        tk.append(f"M{x} 0V{h}")
        if i % 10 == 0:
            s.append(t(x, 27, str(i // 10), 10, 0, col))
    s.append(f'<path stroke="{col}" stroke-width="0.55" d="{"".join(tk)}"/>')
    s.append(f'<circle cx="{L - 12}" cy="28" r="5" fill="none" stroke="{col}" stroke-width="0.9"/>')
    return "".join(s)


def square(col=TOOL):
    s = [f'<path fill="{TFILL}" stroke="{col}" stroke-width="1.2" d="M0 0 L0 380 L240 380 Z M38 112 L38 342 L176 342 Z" fill-rule="evenodd"/>']
    tk = []
    for i in range(0, 120):
        y = 10 + i * 3
        if y > 370: break
        h = 12 if i % 10 == 0 else (8 if i % 5 == 0 else 4)
        tk.append(f"M0 {y}H{h}")
    for i in range(0, 76):
        x = 10 + i * 3
        h = 12 if i % 10 == 0 else (8 if i % 5 == 0 else 4)
        tk.append(f"M{x} 380V{380 - h}")
    s.append(f'<path stroke="{col}" stroke-width="0.55" d="{"".join(tk)}"/>')
    s.append(t(60, 372, "45°", 11, 0, col))
    return "".join(s)


def protractor(col=TOOL, R=210):
    s = [f'<path fill="{TFILL}" stroke="{col}" stroke-width="1.2" d="M{-R} 0 A{R} {R} 0 0 1 {R} 0 Z"/>',
         f'<path fill="none" stroke="{col}" stroke-width="0.8" d="M{-R * .62:.1f} 0 A{R * .62:.1f} {R * .62:.1f} 0 0 1 {R * .62:.1f} 0"/>']
    tk = []
    for d in range(0, 181):
        a = math.radians(180 - d)
        L = 18 if d % 10 == 0 else (11 if d % 5 == 0 else 6)
        x1, y1 = R * math.cos(a), -R * math.sin(a)
        x2, y2 = (R - L) * math.cos(a), -(R - L) * math.sin(a)
        tk.append(f"M{x1:.1f} {y1:.1f}L{x2:.1f} {y2:.1f}")
        if d % 10 == 0 and 0 < d < 180:
            tx, ty = (R - 32) * math.cos(a), -(R - 32) * math.sin(a)
            s.append(t(tx, ty + 3, str(d), 9, 90 - d, col))
    s.append(f'<path stroke="{col}" stroke-width="0.55" d="{"".join(tk)}"/>')
    s.append(ln(-12, 0, 12, 0, 1, col) + ln(0, -12, 0, 0, 1, col))
    return "".join(s)


def pencil(col=TOOL):
    s = [f'<path fill="{TFILL}" stroke="{col}" stroke-width="1.2" d="M0 0 L520 0 L590 15 L520 30 L0 30 Z"/>',
         ln(0, 10, 520, 10, 0.6, col), ln(0, 20, 520, 20, 0.6, col),
         f'<path fill="{col}" d="M575 11.8 L590 15 L575 18.2 Z"/>',
         ln(520, 0, 520, 30, 0.9, col),
         f'<rect x="-46" y="-1" width="46" height="32" fill="{TFILL}" stroke="{col}" stroke-width="1.1"/>',
         ln(-30, -1, -30, 31, 0.6, col), ln(-22, -1, -22, 31, 0.6, col),
         f'<rect x="-80" y="1" width="34" height="28" rx="6" fill="{TFILL}" stroke="{col}" stroke-width="1.1"/>',
         t(260, 20, "2H  ·  ТЕХНО", 10, 0, col)]
    return "".join(s)


def divider(col=TOOL):
    s = [f'<path fill="{TFILL}" stroke="{col}" stroke-width="1.1" d="M-8 0 L-60 330 L-54 332 L4 6 Z"/>',
         f'<path fill="{TFILL}" stroke="{col}" stroke-width="1.1" d="M8 0 L90 320 L84 323 L-4 6 Z"/>',
         f'<circle cx="0" cy="0" r="16" fill="{TFILL}" stroke="{col}" stroke-width="1.2"/>',
         f'<rect x="-5" y="-48" width="10" height="34" rx="3" fill="{TFILL}" stroke="{col}" stroke-width="1"/>',
         f'<path fill="none" stroke="{col}" stroke-width="0.7" stroke-dasharray="4 3" d="M-57 331 A320 320 0 0 0 87 321"/>']
    return "".join(s)


TOOLS = {"caliper": (caliper, 800, 280), "tape": (tape, 800, 200), "ruler": (ruler, 900, 42), "square": (square, 240, 380),
         "protractor": (protractor, 420, 210), "pencil": (pencil, 670, 30), "divider": (divider, 150, 380)}


# ---------------------------------------------------------------- items
def item_group(key, x, y, scale_px, rot, show_tag, rng):
    (w, h), b64 = img_b64(key, int(scale_px * 2.2))
    k = scale_px / max(w, h)
    W, H = w * k, h * k
    L, Wd, Hh = DIMS.get(key, ("", "", ""))
    art, name = NAMES[key]
    s = [f'<g transform="translate({x:.1f} {y:.1f}) rotate({rot:.1f} {W / 2:.1f} {H / 2:.1f})">',
         f'<image x="0" y="0" width="{W:.1f}" height="{H:.1f}" href="data:image/png;base64,{b64}"/>']
    if L:
        yy = H + 16
        s.append(ln(0, H + 4, 0, yy + 6, 0.5) + ln(W, H + 4, W, yy + 6, 0.5))
        s.append(ln(0, yy, W, yy, 0.6) + arr(W, yy, 1, 0) + arr(0, yy, -1, 0) + t(W / 2, yy - 3, L, 11))
    if Hh:
        xx = -16
        s.append(ln(-4, 0, xx - 6, 0, 0.5) + ln(-4, H, xx - 6, H, 0.5))
        s.append(ln(xx, 0, xx, H, 0.6) + arr(xx, H, 0, 1) + arr(xx, 0, 0, -1) + t(xx - 3, H / 2, Hh, 11, -90))
    if show_tag and os.environ.get("NOTAG") == "1":
        rng.uniform(0.55, 0.85); rng.uniform(26, 46)
    elif show_tag:
        tw = max(len(name) * 5.2 + 16, len(art) * 8 + 50)
        tx, ty = W * rng.uniform(0.55, 0.85), -rng.uniform(26, 46)
        s.append(ln(W * 0.5, H * 0.18, tx, ty + 34, 0.6) + f'<circle cx="{W * 0.5:.1f}" cy="{H * 0.18:.1f}" r="2" fill="{INK}"/>')
        s.append(f'<rect x="{tx:.1f}" y="{ty:.1f}" width="{tw:.1f}" height="34" fill="{BG}" stroke="{INK}" stroke-width="0.9"/>')
        s.append(ln(tx, ty + 17, tx + tw, ty + 17, 0.5))
        s.append(t(tx + 6, ty + 13.5, art, 12.5, 0, INK, "start", "bold"))
        s.append(t(tx + 6, ty + 29.5, name, 10, 0, INK, "start"))
    s.append("</g>")
    return "".join(s), (x - 30, y - 50, x + W + 10, y + H + 30)


def overlap(a, b):
    w = min(a[2], b[2]) - max(a[0], b[0]); h = min(a[3], b[3]) - max(a[1], b[1])
    return max(w, 0) * max(h, 0)


def compose(W, H, base, seed, n_frag, tools_plan, out):
    rng = random.Random(seed)
    parts = [f'<rect width="{W}" height="{H}" fill="{BG}"/>']
    # grid
    g = "".join(f"M{x} 0V{H}" for x in range(0, W + 1, 20)) + "".join(f"M0 {y}H{W}" for y in range(0, H + 1, 20))
    parts.append(f'<path stroke="{M.FAINT2}" stroke-width="0.35" fill="none" d="{g}"/>')
    g = "".join(f"M{x} 0V{H}" for x in range(0, W + 1, 100)) + "".join(f"M0 {y}H{W}" for y in range(0, H + 1, 100))
    parts.append(f'<path stroke="{M.FAINT2}" stroke-width="0.7" fill="none" d="{g}"/>')
    parts.append(M.background(W, H, rng, n_frag).split("</path>", 2)[-1] if False else "")
    frag = []
    kinds = ["flange", "shaft", "bracket", "tol", "rough", "sect", "lead"]
    for i in range(n_frag):
        k = kinds[i % len(kinds)]
        x, y = rng.uniform(-40, W - 60), rng.uniform(0, H - 20)
        sc = rng.uniform(0.9, 1.7)
        fn = {"flange": lambda: M.frag_flange(0, 0, rng.uniform(45, 90), rng), "shaft": lambda: M.frag_shaft(0, 0, rng.uniform(170, 280), rng),
              "bracket": lambda: M.frag_bracket(0, 0, rng.uniform(130, 190), rng), "tol": lambda: M.frag_tol(0, 0, rng),
              "rough": lambda: M.frag_rough(0, 0, rng), "sect": lambda: M.frag_section_mark(0, 0, rng.choice("АБВГ")),
              "lead": lambda: M.frag_leaders(0, 0, rng)}[k]
        frag.append(f'<g transform="translate({x:.1f} {y:.1f}) rotate({rng.uniform(-12, 12):.1f}) scale({sc:.2f})">{fn()}</g>')
    parts.append("".join(frag))
    # tools under items
    over = []
    for name, x, y, rot, sc, on_top in tools_plan:
        g = f'<g transform="translate({x} {y}) rotate({rot}) scale({sc})">{TOOLS[name][0]()}</g>'
        (over if on_top else parts).append(g)
    # items
    keys = [k for k in SIZE if k != "C3-27" and os.path.exists(f"./lines/{k}.png")]
    keys.sort(key=lambda k: -SIZE[k])
    placed = []
    groups = []
    for key in keys:
        sz = base * SIZE[key] * rng.uniform(0.9, 1.12)
        best = None
        for _ in range(500):
            x = rng.uniform(-0.18 * sz, W - 0.82 * sz); y = rng.uniform(-0.1 * sz, H - 0.85 * sz)
            box = (x - 30, y - 50, x + sz + 10, y + sz + 30)
            ov = sum(overlap(box, b) for b in placed) / (sz * sz)
            edge = 0
            score = ov + rng.uniform(0, 0.08)
            if best is None or score < best[0]:
                best = (score, x, y)
        _, x, y = best
        rot = rng.choice([-1, 1]) * rng.uniform(6, float(os.environ.get("ROTMAX", 35)))
        gtxt, box = item_group(key, x, y, sz, rot, rng.random() < 0.75, rng)
        placed.append(box)
        groups.append(gtxt)
    rng.shuffle(groups)
    parts.extend(groups)
    parts.extend(over)
    # hero bar: long olympic bar across (vector)
    Lb = W * (0.56 if W > H else 0.95)
    k = Lb / 2200.0
    bx, by = W * rng.uniform(0.03, 0.4) if W > H else W * 0.02, H * rng.uniform(0.3, 0.62)
    rot = rng.choice([-8, -6, 6, 8])
    def R(x0, x1, hh, extra=""):
        return f'<rect x="{x0 * k:.1f}" y="{-hh * k / 2:.1f}" width="{(x1 - x0) * k:.1f}" height="{hh * k:.1f}" fill="{BG}" stroke="{INK}" stroke-width="1.1"{extra}/>'
    g = [R(0, 415, 50), R(415, 445, 70), R(445, 1755, 28), R(1755, 1785, 70), R(1785, 2200, 50)]
    kn = "".join(f"M{x * k:.1f} {-14 * k:.1f}l{3:.1f} {28 * k:.1f}" for x in list(range(560, 1000, 9)) + list(range(1200, 1640, 9)))
    g.append(f'<path stroke="{INK}" stroke-width="0.4" fill="none" d="{kn}"/>')
    for xx in (60, 360, 1840, 2140):
        g.append(ln(xx * k, -25 * k, xx * k, 25 * k, 0.5))
    g.append(ln(-40, 0, Lb + 40, 0, 0.5, INK, "14 3 2 3"))
    yd = 48
    g.append(ln(0, 30, 0, yd + 6, 0.5) + ln(Lb, 30, Lb, yd + 6, 0.5) + ln(0, yd, Lb, yd, 0.6) + arr(Lb, yd, 1, 0) + arr(0, yd, -1, 0))
    g.append(t(Lb / 2, yd - 4, "2200", 11))
    g.append(t(415 * k / 2, -36, "Ø50", 10.5) + t(1100 * k, -22, "Ø28", 10.5))
    g.append(f'<rect x="{Lb * 0.62:.1f}" y="{yd + 10}" width="210" height="34" fill="{BG}" stroke="{INK}" stroke-width="0.9"/>' + ln(Lb * 0.62, yd + 27, Lb * 0.62 + 210, yd + 27, 0.5)
             + t(Lb * 0.62 + 6, yd + 23.5, "C3-27", 12.5, 0, INK, "start", "bold") + t(Lb * 0.62 + 6, yd + 39.5, "Гриф олімпійський, 680 кг", 10, 0, INK, "start"))
    if os.environ.get('BAR') == '1': parts.insert(len(parts) - len(over) - len(groups) + len(groups) // 2, f'<g transform="translate({bx:.0f} {by:.0f}) rotate({rot})">' + "".join(g) + "</g>")
    # frame fragments
    fr = [f'<path stroke="{INK}" stroke-width="1.6" fill="none" d="M14 {H * 0.32:.0f} V14 H{W * 0.42:.0f} M{W * 0.62:.0f} {H - 14} H{W - 14} V{H * 0.55:.0f}"/>']
    for i in range(1, 8):
        x = 14 + i * W * 0.42 / 8
        fr.append(ln(x, 4, x, 14, 0.8) + t(x - W * 0.42 / 16, 12, str(i), 9.5))
    bw2, bh2 = min(470, W * 0.7), 92
    NOTB = os.environ.get("NOTB") == "1"
    bx2, by2 = W - 14 - bw2 + 60, H - 14 - bh2
    if not NOTB: fr.append(f'<rect x="{bx2:.0f}" y="{by2:.0f}" width="{bw2 + 60:.0f}" height="{bh2 + 30}" fill="{BG}" stroke="{INK}" stroke-width="1.6"/>')
    if not NOTB: fr.append(ln(bx2, by2 + 46, W, by2 + 46, 0.8) + ln(bx2 + bw2 * 0.62, by2, bx2 + bw2 * 0.62, H, 0.8))
    if not NOTB: lw_, lh_ = Image.open(LOGO).size
    if not NOTB: lw = bw2 * 0.5; lh = lw * lh_ / lw_
    if not NOTB: lb64 = base64.b64encode(open(LOGO, "rb").read()).decode()
    if not NOTB: fr.append(f'<image x="{bx2 + bw2 * 0.31 - lw / 2:.1f}" y="{by2 + 23 - lh / 2:.1f}" width="{lw:.1f}" height="{lh:.1f}" href="data:image/png;base64,{lb64}"/>')
    if not NOTB: fr.append(t(bx2 + bw2 * 0.31, by2 + 70, "майданчики · вуличні · професійні тренажери", 11.5))
    if not NOTB: fr.append(t(bx2 + bw2 * 0.62 + 10, by2 + 28, "Загальні види", 12, 0, INK, "start"))
    if not NOTB: fr.append(t(bx2 + bw2 * 0.62 + 10, by2 + 70, "Аркуш 1", 11, 0, INK, "start"))
    parts.append("".join(fr))
    svg = (f'<?xml version="1.0" encoding="UTF-8"?>\n<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W * 2}" height="{H * 2}">'
           + "".join(parts) + "</svg>")
    open(out, "w", encoding="utf-8").write(svg)


BASE_D = float(os.environ.get("BASE_D", 245)); BASE_P = float(os.environ.get("BASE_P", 165))

if __name__ == "__main__":
    which = sys.argv[1]; seed = int(sys.argv[2]) if len(sys.argv) > 2 else 3
    if which == "desktop":
        plan = [("caliper", 1180, 610, -18, 1.25, False), ("tape", -60, 760, 8, 1.1, False), ("protractor", 980, 1080, 0, 1.3, False),
                ("square", 1650, 20, 14, 1.2, False), ("ruler", 300, -10, 4, 1.3, True), ("pencil", 560, 980, -22, 1.0, True),
                ("divider", 120, 60, -24, 1.0, False)]
        compose(1920, 1080, BASE_D, seed, 40, [], "./art_desktop.svg")
    else:
        plan = [("caliper", 560, 380, 64, 0.75, False), ("tape", -70, 1080, -14, 0.7, False), ("protractor", 330, 1398, 0, 0.75, False),
                ("square", 450, 60, 18, 0.75, False), ("ruler", -30, 760, -24, 0.72, True), ("pencil", 60, 300, 30, 0.62, True)]
        compose(645, 1398, BASE_P, seed, 20, [], "./art_phone.svg")
