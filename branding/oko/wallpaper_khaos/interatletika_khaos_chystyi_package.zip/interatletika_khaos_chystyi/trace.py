import cv2, numpy as np, sys, os, glob
from scipy import ndimage

INK = (156, 173, 185)
BGC = (226, 234, 239)


def trace(path, out, target=1300, lo=40, hi=110, line=3, sg=195, ss=25):
    im = cv2.imread(path)
    h, w = im.shape[:2]
    k = target / max(h, w)
    im = cv2.resize(im, (int(w * k), int(h * k)), interpolation=cv2.INTER_AREA)
    # object mask: not near-white
    hsv = cv2.cvtColor(im, cv2.COLOR_BGR2HSV)
    gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
    nonwhite = ((gray < 238) | (hsv[..., 1] > 28)).astype(np.uint8)
    nonwhite = cv2.morphologyEx(nonwhite, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    nonwhite = cv2.morphologyEx(nonwhite, cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8))
    lab, n = ndimage.label(nonwhite)
    if n:
        sizes = ndimage.sum(nonwhite, lab, range(1, n + 1))
        keep = np.isin(lab, [i + 1 for i, s in enumerate(sizes) if s > 0.002 * nonwhite.size])
    else:
        keep = nonwhite.astype(bool)
    # drop soft shadow: shadows are low saturation, mid-light gray, wide & at bottom -> remove pixels with gray>200 & sat<25
    shadow = (gray > sg) & (hsv[..., 1] < ss)
    mask = keep & ~shadow
    mask = cv2.morphologyEx(mask.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8)).astype(bool)
    mask = ndimage.binary_fill_holes(mask)
    # edges: smooth colors then canny on L and on chroma
    sm = cv2.bilateralFilter(im, 9, 60, 9)
    sm = cv2.pyrMeanShiftFiltering(sm, 8, 22)
    labi = cv2.cvtColor(sm, cv2.COLOR_BGR2LAB)
    e = np.zeros(gray.shape, np.uint8)
    for c in range(3):
        e |= cv2.Canny(labi[..., c], lo, hi)
    # silhouette outline
    m8 = mask.astype(np.uint8) * 255
    sil = cv2.morphologyEx(m8, cv2.MORPH_GRADIENT, np.ones((3, 3), np.uint8))
    e = e & m8
    # remove tiny edge specks
    lab2, n2 = ndimage.label(e > 0, structure=np.ones((3, 3)))
    if n2:
        sz = ndimage.sum(e > 0, lab2, range(1, n2 + 1))
        e = np.isin(lab2, [i + 1 for i, s in enumerate(sz) if s >= 14]).astype(np.uint8) * 255
    if line > 1:
        e = cv2.dilate(e, np.ones((line, line), np.uint8))
    sil = cv2.dilate(sil, np.ones((2, 2), np.uint8))
    lines = (e > 0) | (sil > 0)
    # compose RGBA: inside mask BG colour, lines INK, outside transparent
    rgba = np.zeros((*gray.shape, 4), np.uint8)
    rgba[mask] = (*BGC, 255)
    rgba[lines] = (*INK, 255)
    # anti-alias by slight blur of alpha on lines
    ys, xs = np.where(mask | lines)
    y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
    rgba = rgba[max(0, y0 - 4):y1 + 4, max(0, x0 - 4):x1 + 4]
    cv2.imwrite(out, rgba)
    return rgba.shape


if __name__ == "__main__":
    os.makedirs("./lines", exist_ok=True)
    for p in sys.argv[1:]:
        name = os.path.basename(p).replace("_1.jpg", "")
        kw = {"TE230": dict(sg=140, ss=30), "TE226": dict(sg=150, ss=28), "TE102": dict(sg=170, ss=25)}.get(name, {})
        print(name, trace(p, f"./lines/{name}.png", **kw))
