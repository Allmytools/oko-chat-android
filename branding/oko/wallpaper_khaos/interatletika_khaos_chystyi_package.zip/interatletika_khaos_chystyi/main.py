import sys, math, random
sys.path.insert(0, ".")
from lib import BG, INK, MID, FONT
import compose

FAINT = "#DDD5CA"
FAINT2 = "#E7E1D8"

ORDER = ["tl101", "se201", "barbell", "ut417", "te208", "mf34", "dumbbell", "te412", "kf811", "rack", "te226",
         "se115", "ut603", "kettlebell", "te102", "mf111", "plate", "te302", "se236", "bench", "te406", "te222"]


def t(x, y, s, size=11, ang=0, col=FAINT, anchor="middle"):
    return (f'<text x="{x:.1f}" y="{y:.1f}" font-size="{size}" fill="{col}" text-anchor="{anchor}" {FONT} '
            f'transform="rotate({ang:.1f} {x:.1f} {y:.1f})">{s}</text>')


def ln(x1, y1, x2, y2, w=0.8, col=FAINT, dash=None):
    d = f' stroke-dasharray="{dash}"' if dash else ""
    return f'<path stroke="{col}" stroke-width="{w}" fill="none"{d} d="M{x1:.1f} {y1:.1f} L{x2:.1f} {y2:.1f}"/>'


def arrow(x, y, ux, uy, col=FAINT, s=6):
    px, py = -uy, ux
    return f'<path fill="{col}" d="M{x:.1f} {y:.1f} L{x - ux * s + px * s * .3:.1f} {y - uy * s + py * s * .3:.1f} L{x - ux * s - px * s * .3:.1f} {y - uy * s - py * s * .3:.1f}Z"/>'


def dimh(x1, x2, y, txt, col=FAINT):
    return (ln(x1, y, x2, y, 0.6, col) + arrow(x2, y, 1, 0, col) + arrow(x1, y, -1, 0, col) + t((x1 + x2) / 2, y - 3, txt, 10, 0, col))


def dimv(x, y1, y2, txt, col=FAINT):
    return (ln(x, y1, x, y2, 0.6, col) + arrow(x, y2, 0, 1, col) + arrow(x, y1, 0, -1, col) + t(x - 3, (y1 + y2) / 2, txt, 10, -90, col))


def hatch_rect(x, y, w, h, step=6, col=FAINT):
    segs = []
    k = -h
    while k < w:
        x1, y1 = x + k, y + h
        x2, y2 = x + k + h, y
        if x1 < x: y1 -= (x - x1); x1 = x
        if x2 > x + w: y2 += (x2 - (x + w)); x2 = x + w
        if x1 < x2: segs.append(f"M{x1:.1f} {y1:.1f}L{x2:.1f} {y2:.1f}")
        k += step
    return f'<path stroke="{col}" stroke-width="0.5" fill="none" d="{"".join(segs)}"/>'


def cl(x1, y1, x2, y2, col=FAINT):
    return ln(x1, y1, x2, y2, 0.6, col, "14 3 2 3")


def frag_flange(cx, cy, R, rng):
    s = []
    for k in (1.0, 0.78, 0.42, 0.3):
        s.append(f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="{R * k:.1f}" fill="none" stroke="{FAINT}" stroke-width="{0.9 if k in (1.0, 0.3) else 0.6}"/>')
    n = rng.choice([4, 6, 8])
    s.append(f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="{R * 0.62:.1f}" fill="none" stroke="{FAINT}" stroke-width="0.5" stroke-dasharray="14 3 2 3"/>')
    for i in range(n):
        a = 2 * math.pi * i / n + math.pi / n
        hx, hy = cx + R * 0.62 * math.cos(a), cy + R * 0.62 * math.sin(a)
        s.append(f'<circle cx="{hx:.1f}" cy="{hy:.1f}" r="{R * 0.07:.1f}" fill="none" stroke="{FAINT}" stroke-width="0.7"/>')
    s.append(cl(cx - R * 1.15, cy, cx + R * 1.15, cy)); s.append(cl(cx, cy - R * 1.15, cx, cy + R * 1.15))
    a0, a1 = -2.3, -0.5
    r2 = R * 1.25
    s.append(f'<path stroke="{FAINT}" stroke-width="0.6" fill="none" d="M{cx + r2 * math.cos(a0):.1f} {cy + r2 * math.sin(a0):.1f} A{r2:.1f} {r2:.1f} 0 0 1 {cx + r2 * math.cos(a1):.1f} {cy + r2 * math.sin(a1):.1f}"/>')
    s.append(t(cx + r2 * math.cos(-1.4), cy + r2 * math.sin(-1.4) - 4, f"{360 // n}°±20'", 10, -10))
    s.append(t(cx + R * 0.15, cy - R * 0.33, f"Ø{rng.choice([40, 52, 60, 76])}H7", 10, -35))
    s.append(t(cx + R * 0.95, cy + R * 0.95, f"{n} отв. Ø{rng.choice([11, 13, 17])}", 10, 0, FAINT, "start"))
    return "".join(s)


def frag_shaft(x, y, L, rng, vertical=False):
    s = []
    steps = [(0, 0.22, 0.32), (0.22, 0.55, 0.5), (0.55, 0.8, 0.4), (0.8, 1.0, 0.26)]
    H = L * 0.28
    for a, b, r in steps:
        x0, x1 = x + a * L, x + b * L
        s.append(f'<rect x="{x0:.1f}" y="{y - H * r:.1f}" width="{x1 - x0:.1f}" height="{2 * H * r:.1f}" fill="none" stroke="{FAINT}" stroke-width="0.9"/>')
    s.append(hatch_rect(x + 0.22 * L, y - H * 0.5, 0.33 * L, H * 0.5 - H * 0.22))
    s.append(f'<rect x="{x + 0.3 * L:.1f}" y="{y - H * 0.08:.1f}" width="{0.18 * L:.1f}" height="{H * 0.16:.1f}" rx="{H * 0.08:.1f}" fill="none" stroke="{FAINT}" stroke-width="0.7"/>')
    s.append(cl(x - 15, y, x + L + 15, y))
    s.append(dimh(x, x + L, y + H * 0.5 + 22, f"{rng.choice([130, 156, 180, 214])}"))
    s.append(dimh(x, x + 0.22 * L, y + H * 0.5 + 8, f"{rng.choice([20, 24, 30])}"))
    s.append(dimv(x - 10, y - H * 0.32, y + H * 0.32, f"Ø{rng.choice([25, 30, 32])}k6"))
    s.append(dimv(x + 0.5 * L, y - H * 0.5, y + H * 0.5, f"Ø{rng.choice([40, 45, 50])}"))
    s.append(t(x + 0.9 * L, y - H * 0.4 - 6, "1,6×45°", 10, 0))
    s.append(t(x + 0.42 * L, y - H * 0.5 - 18, "А–А", 13))
    return "".join(s)


def frag_bracket(x, y, w, rng):
    h = w * 0.55
    s = [f'<path stroke="{FAINT}" stroke-width="0.9" fill="none" d="M{x:.1f} {y:.1f} H{x + w * 0.62:.1f} A{h / 2:.1f} {h / 2:.1f} 0 0 1 {x + w * 0.62:.1f} {y + h:.1f} H{x:.1f}Z"/>']
    s.append(f'<circle cx="{x + w * 0.62:.1f}" cy="{y + h / 2:.1f}" r="{h * 0.24:.1f}" fill="none" stroke="{FAINT}" stroke-width="0.9"/>')
    s.append(f'<circle cx="{x + w * 0.16:.1f}" cy="{y + h / 2:.1f}" r="{h * 0.12:.1f}" fill="none" stroke="{FAINT}" stroke-width="0.8"/>')
    s.append(cl(x + w * 0.62, y - 10, x + w * 0.62, y + h + 10)); s.append(cl(x - 8, y + h / 2, x + w + 8, y + h / 2))
    s.append(dimh(x, x + w * 0.62, y - 14, f"{rng.choice([90, 110, 125])}"))
    s.append(t(x + w * 0.85, y + h + 18, f"R{rng.choice([25, 30, 40])}", 10))
    s.append(t(x + w * 0.62 + h * 0.3, y + h * 0.15, f"Ø{rng.choice([30, 40])}", 10, -30))
    return "".join(s)


def frag_tol(x, y, rng):
    cells = [("⊥", 18), (f"0,0{rng.choice([3, 5, 8])}", 34), (rng.choice(["А", "Б", "В"]), 18)]
    s = []; cx = x
    for txt, w in cells:
        s.append(f'<rect x="{cx:.1f}" y="{y:.1f}" width="{w}" height="16" fill="none" stroke="{FAINT}" stroke-width="0.7"/>')
        s.append(t(cx + w / 2, y + 12, txt, 10.5)); cx += w
    return "".join(s)


def frag_rough(x, y, rng):
    return (f'<path stroke="{FAINT}" stroke-width="0.8" fill="none" d="M{x:.1f} {y:.1f} l5 9 l12 -22 h26"/>' +
            t(x + 30, y - 16, f"Ra {rng.choice(['1,6', '3,2', '6,3', '12,5'])}", 10))


def frag_section_mark(x, y, letter):
    return (ln(x, y, x, y + 26, 1.6) + ln(x, y, x + 14, y, 0.8) + arrow(x + 18, y, 1, 0) + t(x + 10, y - 6, letter, 13) +
            ln(x + 220, y, x + 220, y + 26, 1.6) + ln(x + 220, y, x + 206, y, 0.8) + arrow(x + 202, y, -1, 0) + t(x + 210, y - 6, letter, 13))


def frag_leaders(x, y, rng):
    s = []
    for i in range(rng.randint(3, 5)):
        n = rng.randint(1, 58)
        ex, ey = x + i * 26, y
        s.append(ln(ex, ey + 4, ex + rng.uniform(-30, 30), ey + 60 + rng.uniform(0, 40), 0.5))
        s.append(ln(ex - 10, ey + 4, ex + 10, ey + 4, 0.7))
        s.append(t(ex, ey, str(n), 11))
    return "".join(s)


def background(W, H, rng, density):
    out = []
    # fine grid
    g = []
    for x in range(0, int(W) + 1, 20):
        g.append(f"M{x} 0V{H}")
    for y in range(0, int(H) + 1, 20):
        g.append(f"M0 {y}H{W}")
    out.append(f'<path stroke="{FAINT2}" stroke-width="0.35" fill="none" d="{"".join(g)}"/>')
    g = []
    for x in range(0, int(W) + 1, 100):
        g.append(f"M{x} 0V{H}")
    for y in range(0, int(H) + 1, 100):
        g.append(f"M0 {y}H{W}")
    out.append(f'<path stroke="{FAINT2}" stroke-width="0.7" fill="none" d="{"".join(g)}"/>')
    kinds = ["flange", "shaft", "bracket", "tol", "rough", "sect", "lead"]
    for i in range(density):
        k = kinds[i % len(kinds)]
        x, y = rng.uniform(20, W - 120), rng.uniform(30, H - 60)
        if k == "flange": out.append(frag_flange(x, y, rng.uniform(40, 85), rng))
        elif k == "shaft": out.append(frag_shaft(x, y, rng.uniform(160, 260), rng))
        elif k == "bracket": out.append(frag_bracket(x, y, rng.uniform(120, 180), rng))
        elif k == "tol": out.append(frag_tol(x, y, rng))
        elif k == "rough": out.append(frag_rough(x, y, rng))
        elif k == "sect": out.append(frag_section_mark(x, y, rng.choice(["А", "Б", "В", "Г"])))
        else: out.append(frag_leaders(x, y, rng))
    return "".join(out)


def frame(W, H, m, zones_x, zones_y):
    s = [f'<rect x="{m}" y="{m}" width="{W - 2 * m}" height="{H - 2 * m}" fill="none" stroke="{INK}" stroke-width="0.8"/>',
         f'<rect x="{m + 14}" y="{m + 14}" width="{W - 2 * m - 28}" height="{H - 2 * m - 28}" fill="none" stroke="{INK}" stroke-width="1.8"/>']
    letters = "АБВГДЕЖИКЛМН"
    for i in range(zones_x):
        x0 = m + 14 + (W - 2 * m - 28) * i / zones_x
        x1 = m + 14 + (W - 2 * m - 28) * (i + 1) / zones_x
        if i: s.append(ln(x0, m, x0, m + 14, 0.8, INK) + ln(x0, H - m - 14, x0, H - m, 0.8, INK))
        s.append(t((x0 + x1) / 2, m + 11, str(i + 1), 10, 0, INK) + t((x0 + x1) / 2, H - m - 3, str(i + 1), 10, 0, INK))
    for j in range(zones_y):
        y0 = m + 14 + (H - 2 * m - 28) * j / zones_y
        y1 = m + 14 + (H - 2 * m - 28) * (j + 1) / zones_y
        if j: s.append(ln(m, y0, m + 14, y0, 0.8, INK) + ln(W - m - 14, y0, W - m, y0, 0.8, INK))
        s.append(t(m + 7, (y0 + y1) / 2 + 4, letters[j], 10, 0, INK) + t(W - m - 7, (y0 + y1) / 2 + 4, letters[j], 10, 0, INK))
    # centering marks
    for (x, y, dx, dy) in [(W / 2, m, 0, 1), (W / 2, H - m, 0, -1), (m, H / 2, 1, 0), (W - m, H / 2, -1, 0)]:
        s.append(ln(x, y, x + dx * 26, y + dy * 26, 1.6, INK))
    return "".join(s)


def title_block(x, y, w, h):
    r = [f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{BG}" stroke="{INK}" stroke-width="1.8"/>']
    c1 = x + w * 0.62
    r.append(ln(c1, y, c1, y + h, 1.2, INK))
    r.append(ln(x, y + h * 0.5, c1, y + h * 0.5, 0.8, INK))
    r.append(ln(c1, y + h * 0.33, x + w, y + h * 0.33, 0.8, INK))
    r.append(ln(c1, y + h * 0.66, x + w, y + h * 0.66, 0.8, INK))
    r.append(ln(c1 + (x + w - c1) / 2, y + h * 0.66, c1 + (x + w - c1) / 2, y + h, 0.8, INK))
    r.append(f'<text x="{(x + c1) / 2:.1f}" y="{y + h * 0.36:.1f}" font-size="{h * 0.27:.1f}" font-weight="bold" fill="{INK}" text-anchor="middle" {FONT} letter-spacing="2">ІНТЕРАТЛЕТИКА</text>')
    r.append(t((x + c1) / 2, y + h * 0.8, "Майданчики · вуличні та силові тренажери", h * 0.12, 0, INK))
    r.append(t((c1 + x + w) / 2, y + h * 0.23, "Загальні види", h * 0.13, 0, INK))
    r.append(t((c1 + x + w) / 2, y + h * 0.56, "Аксонометрія · розміри в мм", h * 0.12, 0, INK))
    r.append(t(c1 + (x + w - c1) * 0.25, y + h * 0.89, "Аркуш 1", h * 0.12, 0, INK))
    r.append(t(c1 + (x + w - c1) * 0.75, y + h * 0.89, "Аркушів 1", h * 0.12, 0, INK))
    return "".join(r)


def scale_bar(x, y, w):
    s = [ln(x, y, x + w, y, 1.2, INK)]
    for i in range(11):
        xx = x + w * i / 10
        s.append(ln(xx, y, xx, y - (8 if i % 5 == 0 else 4), 0.8, INK))
    for i in range(5):
        if i % 2 == 0:
            s.append(f'<rect x="{x + w * i / 5:.1f}" y="{y + 2}" width="{w / 5:.1f}" height="4" fill="{INK}"/>')
        else:
            s.append(f'<rect x="{x + w * i / 5:.1f}" y="{y + 2}" width="{w / 5:.1f}" height="4" fill="none" stroke="{INK}" stroke-width="0.6"/>')
    s.append(t(x, y + 18, "0", 10, 0, INK) + t(x + w, y + 18, "1000", 10, 0, INK) + t(x + w / 2, y + 18, "500", 10, 0, INK))
    return "".join(s)


MISSING = []


def place(W, H, inner, blocked, scale, rng, pad=16):
    placed = []
    rects = list(blocked)
    x0, y0, x1, y1 = inner
    for key in ORDER:
        body, bb = compose.RENDERED[key]
        w, h = (bb[2] - bb[0]) * scale, (bb[3] - bb[1]) * scale
        best = None
        yy = y0
        while yy <= y1 - h and best is None:
            xx = x0 + rng.uniform(0, 10)
            while xx <= x1 - w:
                if all(xx + w + pad <= a or a2 + pad <= xx or yy + h + pad <= b or b2 + pad <= yy for (a, b, a2, b2) in rects):
                    best = (0, xx, yy); break
                xx += 7
            yy += 7
        if best is None:
            print("NO PLACE", key); MISSING.append(key); continue
        _, x, y = best
        rects.append((x, y, x + w, y + h))
        placed.append(f'<g transform="translate({x:.1f} {y:.1f}) scale({scale}) translate({-bb[0]:.1f} {-bb[1]:.1f})">{body}</g>')
    return "".join(placed), rects


def build(name, W, H, m, zx, zy, tb, sb, scale, density, seed):
    rng = random.Random(seed)
    parts = [f'<rect width="{W}" height="{H}" fill="{BG}"/>', background(W, H, rng, density)]
    inner = (m + 30, m + 30, W - m - 30, H - m - 30)
    blocked = [tb, (sb[0] - 10, sb[1] - 20, sb[0] + sb[2] + 10, sb[1] + 24)]
    items, rects = place(W, H, inner, blocked, scale, rng)
    parts.append(items)
    parts.append(frame(W, H, m, zx, zy))
    parts.append(title_block(tb[0], tb[1], tb[2] - tb[0], tb[3] - tb[1]))
    parts.append(scale_bar(sb[0], sb[1], sb[2]))
    svg = (f'<?xml version="1.0" encoding="UTF-8"?>\n<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" '
           f'width="{W * 2}" height="{H * 2}">' + "".join(parts) + "</svg>")
    open(f"./{name}.svg", "w", encoding="utf-8").write(svg)


if __name__ == "__main__":
    W, H = 1920, 1080
    import sys
    which = sys.argv[1] if len(sys.argv) > 1 else "desktop"
    sc = float(sys.argv[2]) if len(sys.argv) > 2 else 1.1
    seed = int(sys.argv[3]) if len(sys.argv) > 3 else 11
    if which == "desktop":
        build("desktop", W, H, 14, 12, 6, (W - 28 - 460, H - 28 - 92, W - 28, H - 28), (60, H - 60, 220), sc, 46, seed)
    else:
        W, H = 645, 1398
        build("phone", W, H, 8, 4, 8, (22, H - 22 - 62, W - 22, H - 22), (40, H - 110, 140), sc, 26, seed)
