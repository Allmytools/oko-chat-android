import math

C = math.cos(math.radians(30))
BG = "#EFEAE2"
INK = "#B9AD9C"
MID = "#C9BFB2"
FAINT = "#D9CDB7"
FONT = 'font-family="Liberation Sans Narrow, Arial Narrow, sans-serif" font-style="italic"'


class Ctx:
    s = 40.0
    bb = None


ctx = Ctx()


def reset(s):
    ctx.s = s
    ctx.bb = [1e9, 1e9, -1e9, -1e9]


def grow(X, Y, pad=0):
    b = ctx.bb
    b[0] = min(b[0], X - pad); b[1] = min(b[1], Y - pad); b[2] = max(b[2], X + pad); b[3] = max(b[3], Y + pad)


def P(x, y, z=0.0):
    s = ctx.s
    X = (x - y) * C * s
    Y = (x + y) * 0.5 * s - z * s
    grow(X, Y)
    return X, Y


def f(p):
    return f"{p[0]:.1f} {p[1]:.1f}"


def dpath(pts, close=False):
    return "M" + " L".join(f(P(*q)) for q in pts) + ("Z" if close else "")


def poly(pts, w=1.1):
    return f'<path fill="{BG}" stroke="{INK}" stroke-width="{w}" stroke-linejoin="round" d="{dpath(pts, True)}"/>'


def pl(pts, w=1.0, col=INK, dash=None):
    da = f' stroke-dasharray="{dash}"' if dash else ""
    return f'<path fill="none" stroke="{col}" stroke-width="{w}" stroke-linecap="round" stroke-linejoin="round"{da} d="{dpath(pts)}"/>'


def tube(pts, d, ow=1.0, minw=1.4):
    dd = dpath(pts); w = max(d * ctx.s, minw)
    return (f'<path fill="none" stroke="{INK}" stroke-width="{w + 2 * ow:.2f}" stroke-linecap="round" stroke-linejoin="round" d="{dd}"/>'
            f'<path fill="none" stroke="{BG}" stroke-width="{w:.2f}" stroke-linecap="round" stroke-linejoin="round" d="{dd}"/>')


def box(x, y, z, dx, dy, dz, w=1.1):
    a = poly([(x + dx, y, z), (x + dx, y + dy, z), (x + dx, y + dy, z + dz), (x + dx, y, z + dz)], w)
    b = poly([(x, y + dy, z), (x + dx, y + dy, z), (x + dx, y + dy, z + dz), (x, y + dy, z + dz)], w)
    t = poly([(x, y, z + dz), (x + dx, y, z + dz), (x + dx, y + dy, z + dz), (x, y + dy, z + dz)], w)
    return a + b + t


def post(x, y, h, a=0.08, z=0.0):
    return box(x - a / 2, y - a / 2, z, a, a, h)


def circ(cx, cy, z, r, n=48, a0=0.0, a1=2 * math.pi):
    return [(cx + r * math.cos(a0 + (a1 - a0) * i / n), cy + r * math.sin(a0 + (a1 - a0) * i / n), z) for i in range(n + 1)]


def vcirc_x(x, cy, cz, r, n=40):
    return [(x, cy + r * math.cos(2 * math.pi * i / n), cz + r * math.sin(2 * math.pi * i / n)) for i in range(n + 1)]


def vcirc_y(cx, y, cz, r, n=40):
    return [(cx + r * math.cos(2 * math.pi * i / n), y, cz + r * math.sin(2 * math.pi * i / n)) for i in range(n + 1)]


def cyl(cx, cy, z0, h, r, w=1.1):
    s = ctx.s
    X, Y = P(cx, cy, z0 + h); X0, Y0 = P(cx, cy, z0)
    rx = r * 1.2247 * s; ry = r * 0.7071 * s
    grow(X - rx, Y - ry); grow(X0 + rx, Y0 + ry)
    side = (f'<path fill="{BG}" stroke="{INK}" stroke-width="{w}" d="M{X - rx:.1f} {Y:.1f} L{X0 - rx:.1f} {Y0:.1f} '
            f'A{rx:.1f} {ry:.1f} 0 0 0 {X0 + rx:.1f} {Y0:.1f} L{X + rx:.1f} {Y:.1f}Z"/>')
    top = f'<ellipse fill="{BG}" stroke="{INK}" stroke-width="{w}" cx="{X:.1f}" cy="{Y:.1f}" rx="{rx:.1f}" ry="{ry:.1f}"/>'
    return side + top


def hull2(pts):
    pts = sorted(set((round(p[0], 2), round(p[1], 2)) for p in pts))
    if len(pts) < 3: return pts
    def cr(o, a, b): return (a[0]-o[0])*(b[1]-o[1]) - (a[1]-o[1])*(b[0]-o[0])
    lo = []
    for p in pts:
        while len(lo) >= 2 and cr(lo[-2], lo[-1], p) <= 0: lo.pop()
        lo.append(p)
    up = []
    for p in reversed(pts):
        while len(up) >= 2 and cr(up[-2], up[-1], p) <= 0: up.pop()
        up.append(p)
    return lo[:-1] + up[:-1]


def hullpoly(pts3, w=1.1):
    sp = [P(*q) for q in pts3]
    h = hull2(sp)
    return f'<path fill="{BG}" stroke="{INK}" stroke-width="{w}" stroke-linejoin="round" d="M' + " L".join(f"{x:.1f} {y:.1f}" for x, y in h) + 'Z"/>'


def xcyl(x0, x1, cy, cz, r, w=1.1, n=40):
    a = vcirc_x(x0, cy, cz, r, n); b = vcirc_x(x1, cy, cz, r, n)
    return hullpoly(a + b, w) + poly(b, w)


def ycyl(y0, y1, cx, cz, r, w=1.1, n=40):
    a = vcirc_y(cx, y0, cz, r, n); b = vcirc_y(cx, y1, cz, r, n)
    return hullpoly(a + b, w) + poly(b, w)


def lerp(a, b, t):
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(3))


# ---------------- drawing annotations ----------------
def _arrow(X, Y, ux, uy, size=6):
    px, py = -uy, ux
    a = (X, Y)
    b = (X - ux * size + px * size * 0.3, Y - uy * size + py * size * 0.3)
    c = (X - ux * size - px * size * 0.3, Y - uy * size - py * size * 0.3)
    return f'<path fill="{INK}" stroke="none" d="M{a[0]:.1f} {a[1]:.1f} L{b[0]:.1f} {b[1]:.1f} L{c[0]:.1f} {c[1]:.1f}Z"/>'


def text_at(X, Y, txt, size=11, ang=0, anchor="middle", col=INK, weight="normal"):
    grow(X, Y, size * 0.9)
    return (f'<text x="{X:.1f}" y="{Y:.1f}" font-size="{size}" text-anchor="{anchor}" fill="{col}" font-weight="{weight}" {FONT}'
            f' transform="rotate({ang:.1f} {X:.1f} {Y:.1f})">{txt}</text>')


def dim(p0, p1, e0, e1, label, size=10.5, flip=False):
    """p0,p1: dimension line ends (3D); e0,e1: points on object for extension lines."""
    A = P(*p0); B = P(*p1); E0 = P(*e0); E1 = P(*e1)
    out = []
    for (E, D) in ((E0, A), (E1, B)):
        vx, vy = D[0] - E[0], D[1] - E[1]; L = math.hypot(vx, vy) or 1
        ex, ey = D[0] + vx / L * 5, D[1] + vy / L * 5
        sx, sy = E[0] + vx / L * 3, E[1] + vy / L * 3
        out.append(f'<path stroke="{INK}" stroke-width="0.55" fill="none" d="M{sx:.1f} {sy:.1f} L{ex:.1f} {ey:.1f}"/>')
    out.append(f'<path stroke="{INK}" stroke-width="0.6" fill="none" d="M{A[0]:.1f} {A[1]:.1f} L{B[0]:.1f} {B[1]:.1f}"/>')
    ux, uy = B[0] - A[0], B[1] - A[1]; L = math.hypot(ux, uy) or 1; ux, uy = ux / L, uy / L
    out.append(_arrow(B[0], B[1], ux, uy)); out.append(_arrow(A[0], A[1], -ux, -uy))
    ang = math.degrees(math.atan2(uy, ux))
    if ang > 90: ang -= 180
    if ang < -90: ang += 180
    mx, my = (A[0] + B[0]) / 2, (A[1] + B[1]) / 2
    ux2, uy2 = math.sin(math.radians(ang)), -math.cos(math.radians(ang))
    k = 3.0 if not flip else -size - 1
    out.append(text_at(mx + ux2 * k, my + uy2 * k, label, size, ang))
    return "".join(out)


def centerline_v(x, y, z0, z1):
    return pl([(x, y, z0), (x, y, z1)], 0.5, INK, "9 3 2 3")


def label(X, Y, art, name, dims, scale):
    w = max(len(name) * 5.0 + 14, 150)
    h = 50
    grow(X, Y); grow(X + w, Y + h)
    return "".join([
        f'<rect x="{X:.1f}" y="{Y:.1f}" width="{w:.1f}" height="{h}" fill="{BG}" stroke="{INK}" stroke-width="0.9"/>',
        f'<path stroke="{INK}" stroke-width="0.55" d="M{X:.1f} {Y + 19:.1f} H{X + w:.1f} M{X:.1f} {Y + 35:.1f} H{X + w:.1f} M{X + w - 44:.1f} {Y:.1f} V{Y + 19:.1f}"/>',
        f'<text x="{X + 6:.1f}" y="{Y + 14.5:.1f}" font-size="13.5" font-weight="bold" fill="{INK}" {FONT}>{art}</text>',
        f'<text x="{X + w - 22:.1f}" y="{Y + 14:.1f}" font-size="10" text-anchor="middle" fill="{INK}" {FONT}>{scale}</text>',
        f'<text x="{X + 6:.1f}" y="{Y + 30.5:.1f}" font-size="10.5" fill="{INK}" {FONT}>{name}</text>',
        f'<text x="{X + 6:.1f}" y="{Y + 46:.1f}" font-size="10" fill="{MID}" {FONT}>{dims}</text>'])
